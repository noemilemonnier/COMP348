#include <stdio.h>
#include <stdbool.h>

bool twoStrComp(char[], char[]);

int main(void)
{
	char x[]= "atest";
	char y[]= "another";
    bool ans = twoStrComp(x,y);
    printf("%s", ans ? "true" : "false");
	
}

bool twoStrComp(char string1[], char string2[] )
{
    int i=0, flag=0;
    bool value = false;
       while(flag==0) {
        if (string1[i]>string2[i])
        {
            flag=1;
            value = false;
        }
        else if (string1[i]<string2[i])
        {
            flag=-1;
            value = true;
        }
        else if (string1[i]==string2[i])
        {
            return 0;
            value = true;
        }
        else
        {
            i++;
        }
    }
    if(flag == 1)
        return (value == false);
    if(flag == -1)
        return (value == true);
 return value;
}
  
