def double(int_values)
    int_values = int_values.sort
    int_values.each  {|element| puts"#{element}   \t#{element*2}"}
end
