def HID_num(str)
    str.split(" ").each do |element|
        matches = element.match(/\A[A-Z]{4}(\d{8})\z/)
        puts matches[1] if matches
    end
end
